import { Url } from 'url';

export interface PokeData {
  pokemonID: string;
  name: string;
  url: string;
  details: any;
}
