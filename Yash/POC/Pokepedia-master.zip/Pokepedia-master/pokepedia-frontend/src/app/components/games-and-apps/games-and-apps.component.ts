import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-games-and-apps',
  templateUrl: './games-and-apps.component.html',
  styleUrls: ['./games-and-apps.component.scss'],
})
export class GamesAndAppsComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
