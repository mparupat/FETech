import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poke-event',
  templateUrl: './poke-event.component.html',
  styleUrls: ['./poke-event.component.scss']
})
export class PokeEventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
