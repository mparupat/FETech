import { AbilitiesFilterPipe } from './abilities-filter.pipe';

describe('AbilitiesFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AbilitiesFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
