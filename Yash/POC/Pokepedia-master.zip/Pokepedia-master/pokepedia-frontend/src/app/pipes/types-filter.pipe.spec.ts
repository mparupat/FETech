import { TypesFilterPipe } from './types-filter.pipe';

describe('TypesFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TypesFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
