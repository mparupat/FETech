export const environment = {
  production: true,
  pokemonURL: 'http://localhost:3000/pokemons',
};
